function out = multi_agent_system(t, z, uHold, p)
%MULTI_AGENT_SYSTEM Self-triggered leader-following MAS simulation model.
% State vector z = [x(:); Ohat(:)], where x and Ohat are N-by-2 matrices.

N = p.N;
n = p.n;
x = reshape(z(1:N*n), N, n);
Ohat = reshape(z(N*n+1:end), N, n);

[yr, dyr, ddyr] = reference_signal(t, p);
[beta, dbeta] = deception_coefficients(t, p);
xhat = beta .* x;

O = zeros(N, n);
dx = zeros(N, n);
dOhat = zeros(N, n);

f1 = p.f1Gain * sin(x(:, 1));
d1 = p.d1Gain * cos(t) * ones(N, 1);
f2 = p.f2Gain * sin(p.f2PositionScale*x(:, 1)) ...
   + p.f2VelocityGain * sin(x(:, 2));
d2 = p.d2Gain * cos(p.d2Freq*t + p.d2AgentPhaseStep*(1:N)');

dx(:, 1) = x(:, 2) + f1 + d1;
dx(:, 2) = uHold + f2 + d2;

O(:, 1) = dbeta(:, 1) ./ beta(:, 1) .* xhat(:, 1) + beta(:, 1) .* (f1 + d1);
O(:, 2) = dbeta(:, 2) ./ beta(:, 2) .* xhat(:, 2) + beta(:, 2) .* (f2 + d2);

for j = 1:n
    Otilde = O(:, j) - Ohat(:, j);
    dOhat(:, j) = p.lambda1 / 2^(1 - 1*p.power) * sigpow(Otilde, 1 - 1*p.power, p) ...
                + p.lambda2 / 2^(1 + 1*p.power) * sigpow(Otilde, 1 + 1*p.power, p) ...
                + p.lambda3 / 2 * sigpow(Otilde, 1, p) ...
                + p.obsK2 * sigpow(Otilde, 0, p);
end

yrVec = yr * ones(N, 1);
dyrVec = dyr * ones(N, 1);
ddyrVec = ddyr * ones(N, 1);

% Backstepping variables from the latest proof:
% s_1=(L+B)(hat{x}_{1}-1_N*y_r),
% phi_{i,1}=beta_{i,1}^{-1}[...], s_{i,2}=hat{x}_{i,2}-phi_{i,1}.
s1 = p.Gamma * (xhat(:, 1) - yrVec);

k1 = p.kMat(:, 1);
k2 = p.kMat(:, 2);
alphaLow = 1 - 2*p.power;
alphaHigh = 1 + 2*p.power;
denLow = 2^(1 - p.power);
denHigh = 2^(1 + p.power);

phiBracket = - k1 ./ denLow .* sigpow(s1, alphaLow, p) ...
             - k1 ./ denHigh .* sigpow(s1, alphaHigh, p) ...
             - (p.power * p.Tc_ctrl / 4) * s1 ...
             + dyrVec ...
             - Ohat(:, 1);
phi1 = phiBracket ./ beta(:, 1);
s2 = xhat(:, 2) - phi1;

dxhat1 = beta(:, 1) .* x(:, 2) + O(:, 1);
ds1 = p.Gamma * (dxhat1 - dyrVec);
dphiBracket = - k1 ./ denLow .* sigpow_dot(s1, ds1, alphaLow, p) ...
              - k1 ./ denHigh .* sigpow_dot(s1, ds1, alphaHigh, p) ...
              - (p.power * p.Tc_ctrl / 4) * ds1 ...
              + ddyrVec ...
              - dOhat(:, 1);
dphi1 = dphiBracket ./ beta(:, 1) ...
       - phiBracket .* dbeta(:, 1) ./ (beta(:, 1).^2);

% Continuous controller w_i(t). The final-step linear damping uses
% p*T_c/2 so that the self-triggered input error term is handled by Young's
% inequality as in the latest stability derivation.
w = (dphi1 ...
    - k2 ./ denLow .* sigpow(s2, alphaLow, p) ...
    - k2 ./ denHigh .* sigpow(s2, alphaHigh, p) ...
    - (p.power * p.Tc_ctrl / 2) * s2 ...
    - Ohat(:, 2) ...
    - beta(:, 1) .* s1) ./ beta(:, 2);


out = struct();
out.dz = [dx(:); dOhat(:)];
out.x = x;
out.xhat = xhat;
out.beta = beta;
out.O = O;
out.Ohat = Ohat;
out.Otilde = O - Ohat;
out.s1 = s1;
out.s2 = s2;
out.phi1 = phi1;
out.dphi1 = dphi1;
out.w = w;
out.u = uHold;
out.eInput = uHold - w;
out.yr = yr;
out.dyr = dyr;
out.ddyr = ddyr;
end

function y = sigpow(x, a, p)
%SIGPOW Smooth signed power sig^a(x)=|x|^a sign(x).
y = (abs(x) + p.sigEps).^a .* tanh(p.sigSlope*x);
end

function ydot = sigpow_dot(x, xdot, a, p)
%SIGPOW_DOT Time derivative of the smoothed signed-power approximation.
absx = abs(x) + p.sigEps;
tanhx = tanh(p.sigSlope*x);
sech2 = 1 - tanhx.^2;
dy_dx = a * absx.^(a - 1) .* sign(x) .* tanhx ...
      + absx.^a .* p.sigSlope .* sech2;
ydot = dy_dx .* xdot;
end

function [yr, dyr, ddyr] = reference_signal(t, p)
% 轨迹计算已完全解耦并移交至 param.m，这里仅负责直接执行匿名函数
yr = p.ref.yr(t);
dyr = p.ref.dyr(t);
ddyr = p.ref.ddyr(t);
end

function [beta, dbeta] = deception_coefficients(t, p)
    % 默认情况：系统正常运行，没有受到攻击（beta = 1.00，导数为 0）
    beta = ones(size(p.betaBase));
    dbeta = zeros(size(p.betaBase));
    
    % 检查当前时间 t 是否落入任何一个灰色攻击区间 (attackWindows) 内
    is_attacked = false;
    for q = 1:size(p.attackWindows, 1)
        if t >= p.attackWindows(q, 1) && t <= p.attackWindows(q, 2)
            is_attacked = true;
            break;
        end
    end
    
    % 只有在攻击区间内，黑客的动态正弦波欺骗才会激活！
    if is_attacked
        beta = p.betaBase + p.betaAmp .* sin(p.betaFreq * t + p.betaPhase);
        dbeta = p.betaAmp .* p.betaFreq .* cos(p.betaFreq * t + p.betaPhase);
        beta = max(beta, p.betaMin); % 安全下界保护
    end
end
