clear; clc; % close all;

p = param();
N = p.N;
n = p.n;
dt = p.dt;
t = 0:dt:p.T;
Nt = numel(t);

%% Initial condition
z = [p.x0(:); p.Ohat0(:)];
uHold = p.uHold0;
nextTrigger = p.nextTrigger0;

% Initialize the actual input with the continuous controller at t = 0.
out0 = multi_agent_system(t(1), z, uHold, p);
uHold = out0.w;
wPrev = out0.w;

triggerTimes = cell(N, 1);
triggerIntervals = cell(N, 1);
lastTriggerTime = zeros(N, 1);
for i = 1:N
    triggerTimes{i} = [];
    triggerIntervals{i} = [];
end

%% Data buffers
X = zeros(Nt, N, n);
Xhat = zeros(Nt, N, n);
U = zeros(Nt, N);
W = zeros(Nt, N);
Einput = zeros(Nt, N);
O = zeros(Nt, N, n);
Ohat = zeros(Nt, N, n);
S1 = zeros(Nt, N);
S2 = zeros(Nt, N);
YR = zeros(Nt, 1);
DYR = zeros(Nt, 1);
triggerMark = false(Nt, N);

%% Visible simulation progress bar
progressBar = create_progress_bar();
progressUpdateStep = max(1, floor(Nt / 100));
progressCleanup = onCleanup(@() close_progress_bar(progressBar));

%% Main simulation loop
for k = 1:Nt
    tk = t(k);

    out = multi_agent_system(tk, z, uHold, p);
    if k == 1
        wdotEst = zeros(N, 1);
    else
        wdotEst = (out.w - wPrev) / dt;
    end

    % Self-triggered input update.
    for i = 1:N
        if tk >= nextTrigger(i) - 1e-12
            uHold(i) = out.w(i);
            triggerMark(k, i) = true;

            if ~isempty(triggerTimes{i})
                triggerIntervals{i}(end + 1, 1) = tk - lastTriggerTime(i);
            end
            triggerTimes{i}(end + 1, 1) = tk;
            lastTriggerTime(i) = tk;
            intervalRaw = (p.iota1(i) * abs(out.w(i)) + p.iota2(i)) / ...
                max(p.Theta(i), abs(wdotEst(i)));
            interval = min(max(intervalRaw, p.minTriggerInterval), p.maxTriggerInterval);
            nextTrigger(i) = tk + interval;
        end
    end

    % Recompute after updating the held control input.
    out = multi_agent_system(tk, z, uHold, p);

    X(k, :, :) = out.x;
    Xhat(k, :, :) = out.xhat;
    U(k, :) = out.u.';
    W(k, :) = out.w.';
    Einput(k, :) = out.eInput.';
    O(k, :, :) = out.O;
    Ohat(k, :, :) = out.Ohat;
    S1(k, :) = out.s1.';
    S2(k, :) = out.s2.';
    YR(k) = out.yr;
    DYR(k) = out.dyr;

    % Fixed-step RK4 integration with held input over the step.
    if k < Nt
        rhs = @(tt, zz) multi_agent_system(tt, zz, uHold, p).dz;
        k1 = rhs(tk, z);
        k2 = rhs(tk + dt/2, z + dt*k1/2);
        k3 = rhs(tk + dt/2, z + dt*k2/2);
        k4 = rhs(tk + dt, z + dt*k3);
        z = z + dt * (k1 + 2*k2 + 2*k3 + k4) / 6;
    end
    wPrev = out.w;

    if k == 1 || mod(k, progressUpdateStep) == 0 || k == Nt
        update_progress_bar(progressBar, k, Nt, tk, t(end));
    end
end
close_progress_bar(progressBar);
clear progressCleanup;

%% Tracking error
trackingError = squeeze(X(:, :, 1)) - YR * ones(1, N);
velocityTrackingError = squeeze(X(:, :, 2)) - DYR * ones(1, N);
observerError = O - Ohat;

%% Console summary
print_parameter_selection(p);
fprintf('Self-triggered predefined-time MAS simulation finished.\n');
fprintf('Number of follower agents: %d\n', N);
for i = 1:N
    if isempty(triggerIntervals{i})
        fprintf('Follower agent %d trigger count: %d\n', i, nnz(triggerMark(:, i)));
    else
        fprintf('Follower agent %d trigger count: %d, mean interval: %.4f s, min interval: %.4f s\n', ...
            i, nnz(triggerMark(:, i)), mean(triggerIntervals{i}), min(triggerIntervals{i}));
    end
end

%% Figure 1: leader-following position trajectories
fig = figure('Name', 'Trajectories of leader and followers', 'Color', p.figureColor, 'Position', [80, 80, 760, 520]);
setup_figure(fig, p);
hold on; box on;
plot(t, YR, 'k-', 'LineWidth', p.plot.leaderLineWidth, 'DisplayName', 'leader');
for i = 1:N
    plot(t, squeeze(X(:, i, 1)), 'LineWidth', p.plot.agentLineWidth, ...
        'DisplayName', sprintf('x_{%d,1}(t)', i));
end
shade_attack_windows(gca, p);
xlabel('Time (s)');
ylabel('States');
title('Trajectories of leader and followers');
legend('Location', 'best');
format_axes(gca, p);
axis padded;
limit_time_axis(gca, t);

%% Figure 2: velocity trajectories of leader and followers
fig = figure('Name', 'Velocity trajectories of leader and followers', 'Color', p.figureColor, 'Position', [100, 100, 760, 520]);
setup_figure(fig, p);
hold on; box on;
plot(t, DYR, 'k-', 'LineWidth', p.plot.leaderLineWidth, 'DisplayName', 'leader');
for i = 1:N
    plot(t, squeeze(X(:, i, 2)), 'LineWidth', p.plot.agentLineWidth, ...
        'DisplayName', sprintf('x_{%d,2}(t)', i));
end
shade_attack_windows(gca, p);
xlabel('Time (s)');
ylabel('Velocities');
title('Velocity trajectories of leader and followers');
legend('Location', 'best');
format_axes(gca, p);
axis padded;
limit_time_axis(gca, t);

%% Figure 3: observer output
fig = figure('Name', 'Output of the observer', 'Color', p.figureColor, 'Position', [120, 120, 760, 700]);
setup_figure(fig, p);

subplot(2,1,1); hold on; box on;
for i = 1:N
    plot(t, squeeze(Ohat(:, i, 1)), 'LineWidth', p.plot.agentLineWidth, ...
        'DisplayName', sprintf('agent%d', i));
end
shade_attack_windows(gca, p);
xlabel('Time (s)');
ylabel('$\hat{O}_{i,1}$', 'Interpreter', 'latex');
title('Output of the observer');
legend('Location', 'best');
format_axes(gca, p);
limit_time_axis(gca, t);

subplot(2,1,2); hold on; box on;
for i = 1:N
    plot(t, squeeze(Ohat(:, i, 2)), 'LineWidth', p.plot.agentLineWidth, ...
        'DisplayName', sprintf('agent%d', i));
end
shade_attack_windows(gca, p);
xlabel('Time (s)');
ylabel('$\hat{O}_{i,2}$', 'Interpreter', 'latex');
title('Output of the observer');
legend('Location', 'best');
format_axes(gca, p);
limit_time_axis(gca, t);

%% Figure 4: observer estimation error
fig = figure('Name', 'Observer estimation error', 'Color', p.figureColor, 'Position', [140, 140, 760, 700]);
setup_figure(fig, p);

subplot(2,1,1); hold on; box on;
for i = 1:N
    plot(t, squeeze(observerError(:, i, 1)), 'LineWidth', p.plot.agentLineWidth, ...
        'DisplayName', sprintf('agent%d', i));
end
shade_attack_windows(gca, p);
yline(0, 'k--', 'LineWidth', p.plot.zeroLineWidth, 'HandleVisibility', 'off');
xlabel('Time (s)');
ylabel('$\widetilde{O}_{i,1}$', 'Interpreter', 'latex');
title('Observer estimation error');
legend('Location', 'best');
format_axes(gca, p);
limit_time_axis(gca, t);

subplot(2,1,2); hold on; box on;
for i = 1:N
    plot(t, squeeze(observerError(:, i, 2)), 'LineWidth', p.plot.agentLineWidth, ...
        'DisplayName', sprintf('agent%d', i));
end
shade_attack_windows(gca, p);
yline(0, 'k--', 'LineWidth', p.plot.zeroLineWidth, 'HandleVisibility', 'off');
xlabel('Time (s)');
ylabel('$\widetilde{O}_{i,2}$', 'Interpreter', 'latex');
title('Observer estimation error');
legend('Location', 'best');
format_axes(gca, p);
limit_time_axis(gca, t);

%% Figure 5: control input
fig = figure('Name', 'Output of the controller', 'Color', p.figureColor, 'Position', [160, 160, 760, 520]);
setup_figure(fig, p);
hold on; box on;
for i = 1:N
    plot(t, W(:, i), 'LineWidth', p.plot.agentLineWidth, 'DisplayName', sprintf('agent%d', i));
end
shade_attack_windows(gca, p);
xlabel('Time (s)');
ylabel('w_i(t)');
title('Output of the controller');
legend('Location', 'best');
format_axes(gca, p);
axis padded;
limit_time_axis(gca, t);

%% Figure 6: position tracking error
fig = figure('Name', 'Tracking error', 'Color', p.figureColor, 'Position', [200, 200, 760, 520]);
setup_figure(fig, p);
hold on; box on;
for i = 1:N
    plot(t, trackingError(:, i), 'LineWidth', p.plot.agentLineWidth, ...
        'DisplayName', sprintf('agent%d', i));
end
shade_attack_windows(gca, p);
yline(0, 'k--', 'LineWidth', p.plot.zeroLineWidth, 'HandleVisibility', 'off');
xlabel('Time (s)');
ylabel('x_{i,1}-y_r');
title('Tracking error');
legend('Location', 'best');
format_axes(gca, p);
axis padded;
limit_time_axis(gca, t);

%% Figure 7: velocity tracking error
fig = figure('Name', 'Velocity tracking error', 'Color', p.figureColor, 'Position', [220, 220, 760, 520]);
setup_figure(fig, p);
hold on; box on;
for i = 1:N
    plot(t, velocityTrackingError(:, i), 'LineWidth', p.plot.agentLineWidth, ...
        'DisplayName', sprintf('agent%d', i));
end
shade_attack_windows(gca, p);
yline(0, 'k--', 'LineWidth', p.plot.zeroLineWidth, 'HandleVisibility', 'off');
xlabel('Time (s)');
ylabel('$x_{i,2}-\dot{y}_r$', 'Interpreter', 'latex');
title('Velocity tracking error');
legend('Location', 'best');
format_axes(gca, p);
axis padded;
limit_time_axis(gca, t);

%% Figure 8: event-triggering instants
fig = figure('Name', 'Trigger time interval of agent i', 'Color', p.figureColor, 'Position', [240, 240, 760, 520]);
setup_figure(fig, p);
hold on; box on;
triggerColors = lines(N);
for i = 1:N
    ti = triggerTimes{i};
    if isempty(ti)
        continue;
    end
    scatter(ti, i * ones(size(ti)), p.plot.triggerMarkerSize, 'o', ...
        'MarkerEdgeColor', triggerColors(i, :), ...
        'MarkerFaceColor', 'none', ...
        'LineWidth', p.plot.triggerLineWidth, ...
        'DisplayName', sprintf('agent%d', i));
end
xlabel('Time');
ylabel('Events');
title('Trigger time interval of agent i');
xlim([t(1), t(end)]);
ylim([0, N + 1]);
yticks(1:N);
legend('Location', 'best');
format_axes(gca, p);
limit_time_axis(gca, t);

function shade_attack_windows(ax, p)
    axes(ax);
    yl = ylim(ax);
    for q = 1:size(p.attackWindows, 1)
        x1 = p.attackWindows(q, 1);
        x2 = p.attackWindows(q, 2);
        h = patch(ax, [x1 x2 x2 x1], [yl(1) yl(1) yl(2) yl(2)], ...
            p.plot.attackColor, 'FaceAlpha', p.plot.attackAlpha, ...
            'EdgeColor', 'k', 'LineWidth', p.plot.attackEdgeWidth, ...
            'HandleVisibility', 'off');
        uistack(h, 'bottom');
    end
    ylim(ax, yl);
end

function setup_figure(fig, p)
    set(fig, 'Renderer', p.plot.renderer);
    if isprop(fig, 'GraphicsSmoothing')
        set(fig, 'GraphicsSmoothing', p.plot.graphicsSmoothing);
    end
end

function limit_time_axis(ax, t)
    xlim(ax, [t(1), t(end)]);
end

function print_parameter_selection(p)
    fprintf('\n========== Parameter selection ==========\n');
    fprintf('N = %d, n = %d, T = %.3f, dt = %.5f\n', p.N, p.n, p.T, p.dt);
    fprintf('\n--- Simulation system ---\n');
    fprintf('For each follower agent i = 1,...,%d:\n', p.N);
    fprintf('  dot{x}_{i,1} = x_{i,2} + f_{i,1}(x_i) + d_{i,1}(t)\n');
    fprintf('  dot{x}_{i,2} = u_i + f_{i,2}(x_i) + d_{i,2}(t)\n');
    fprintf('  y_r = x_{r,1}\n');
    fprintf('  hat{x}_{i,l} = beta_{i,l}(t) x_{i,l}, l = 1,2\n');
    fprintf('  s_1 = (L+B)(hat{x}_{1}-1_N*y_r)\n');
    fprintf('  phi_{i,1}=beta_{i,1}^{-1}[ -k_{i,1}/2^{1-p} sig^{1-2p}(s_{i,1})\n');
    fprintf('      -k_{i,1}/2^{1+p} sig^{1+2p}(s_{i,1}) - p*T_c*s_{i,1}/4 + dot{y}_r - hat{O}_{i,1}]\n');
    fprintf('  s_{i,2}=hat{x}_{i,2}-phi_{i,1}\n');
    fprintf('  w_i=beta_{i,2}^{-1}[dot{phi}_{i,1}-k_{i,2}/2^{1-p}sig^{1-2p}(s_{i,2})\n');
    fprintf('      -k_{i,2}/2^{1+p}sig^{1+2p}(s_{i,2})-p*T_c*s_{i,2}/2-hat{O}_{i,2}-beta_{i,1}s_{i,1}]\n');
    fprintf('  f_{i,1}=%.3f*sin(x_{i,1}), d_{i,1}=%.3f*cos(t)\n', p.f1Gain, p.d1Gain);
    fprintf('  f_{i,2}=%.3f*sin(%.3f*x_{i,1}) + %.3f*sin(x_{i,2})\n', ...
        p.f2Gain, p.f2PositionScale, p.f2VelocityGain);
    fprintf('  d_{i,2}=%.3f*cos(%.3f*t + %.3f*i)\n', ...
        p.d2Gain, p.d2Freq, p.d2AgentPhaseStep);

    fprintf('\n--- Leader reference signal ---\n');
    fprintf('Reference expression: %s\n', p.ref.expression);
    fprintf('Leader initial position: y_r(0) = %.3f\n', p.ref.yr(0));
    fprintf('Leader initial velocity: dot{y}_r(0) = %.3f\n', p.ref.dyr(0));
    fprintf('Leader initial acceleration: ddot{y}_r(0) = %.3f\n', p.ref.ddyr(0));

    fprintf('\n--- Controller and observer parameters ---\n');
    fprintf('Target practical settling time: %.3f s\n', p.Ttarget);
    fprintf('Tc_ctrl = %.3f, Tc_obs = %.3f, p = %.3f\n', p.Tc_ctrl, p.Tc_obs, p.power);
    fprintf('k = [%.3f, %.3f]\n', p.k(1), p.k(2));
    fprintf('sigEps = %.1e, sigSlope = %.3f\n', p.sigEps, p.sigSlope);
    fprintf('k1 = min{k_{i,j}, 1/(p*Tc)} = %.6f\n', p.k1Bound);
    fprintf('Practical settling-time bound: %.6f s\n', p.practicalTimeBound);
    fprintf('lambda1 = %.6f, lambda2 = %.6f, lambda3 = %.6f\n', ...
        p.lambda1, p.lambda2, p.lambda3);
    fprintf('Self-triggered parameters by agent:\n');
    fprintf('  iota1 = '); fprintf('%.3f ', p.iota1); fprintf('\n');
    fprintf('  iota2 = '); fprintf('%.3f ', p.iota2); fprintf('\n');
    fprintf('  Theta = '); fprintf('%.3f ', p.Theta); fprintf('\n');
    fprintf('  steady lower-scale intervals iota2/Theta = ');
    fprintf('%.3f ', p.iota2 ./ p.Theta); fprintf('s\n');
    fprintf('  simulation interval clamp: [%.4f, %.4f] s\n', ...
        p.minTriggerInterval, p.maxTriggerInterval);

    fprintf('\n--- Initial conditions ---\n');
    fprintf('Follower initial positions x_{i,1}(0):\n');
    disp(p.x0(:, 1).');
    fprintf('Check initial positions in position figure: leader starts at %.3f, followers start at:\n', ...
        p.ref.yr(0));
    disp(p.x0(:, 1).');
    fprintf('Follower initial velocities x_{i,2}(0):\n');
    disp(p.x0(:, 2).');
    fprintf('Initial states [position, velocity]:\n');
    disp(p.x0);

    fprintf('\n--- Communication topology ---\n');
    fprintf('Leader adjacency B:\n');
    disp(p.B);
    fprintf('Follower Laplacian L:\n');
    disp(p.L);

    fprintf('\n--- Deception attacks ---\n');
    fprintf('beta_{i,l}(t) = betaBase_{i,l} + betaAmp_{i,l}*sin(betaFreq_{i,l}*t + betaPhase_{i,l})\n');
    fprintf('Attack windows:\n');
    disp(p.attackWindows);
    fprintf('betaBase:\n');
    disp(p.betaBase);
    fprintf('betaAmp:\n');
    disp(p.betaAmp);
    fprintf('=========================================\n\n');
end

function format_axes(ax, p)
    set(ax, 'Color', 'w', ...
        'LineWidth', p.plot.axisLineWidth, ...
        'FontName', p.plot.fontName, ...
        'FontSize', p.plot.fontSize, ...
        'XGrid', 'on', ...
        'YGrid', 'on', ...
        'GridAlpha', p.plot.gridAlpha);
    xlabel(ax, ax.XLabel.String, 'FontName', p.plot.fontName, 'FontWeight', 'bold');
    ylabel(ax, ax.YLabel.String, 'FontName', p.plot.fontName, 'FontWeight', 'bold');
end

function h = create_progress_bar()
    h = waitbar(0, 'Simulation progress: 0.00%', ...
        'Name', 'Simulation Progress');
    drawnow;
end

function update_progress_bar(h, k, Nt, tk, tEnd)
    if isempty(h) || ~ishandle(h)
        return;
    end
    progressRatio = k / Nt;
    progressPercent = 100 * progressRatio;
    progressText = sprintf('Simulation progress: %.2f%%  (t = %.3f / %.3f s)', ...
        progressPercent, tk, tEnd);
    waitbar(progressRatio, h, progressText);
    drawnow limitrate;
end

function close_progress_bar(h)
    if ~isempty(h) && ishandle(h)
        close(h);
    end
end
