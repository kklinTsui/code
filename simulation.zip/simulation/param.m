function p = param()
%PARAM Parameter settings for the predefined-time MAS simulation.
% All adjustable simulation, controller, observer, attack, trigger, and
% plotting parameters are collected here for easier tuning.

p = struct();

%% 1. Basic simulation settings
p.N = 5;                    % Number of follower agents.
p.n = 2;                    % Order of each follower system.
p.T = 25;                   % Simulation horizon, in seconds.
p.dt = 2e-4;                % Fixed integration step used by RK4; smaller dt gives smoother curves.
p.plotStep = 10;            % Reserved recording interval for dense data.
p.figureColor = 'w';        % Figure background color.
p.observerAgentIndex = 1;   % Representative observer index if single-agent plots are needed.

%% 2. Communication topology
% L is the exact follower Laplacian matrix derived from your specific rules
p.L = [ 0  0  0  0  0;
       -1  2 -1  0  0;
        0  0  1  0 -1;
       -1  0  0  1  0;
        0 -1  0 -1  2];

% A(i,j)=1 means follower i receives information from follower j.
p.A = [0  0  0  0  0;
       1  0  1  0  0;
       0  0  0  0  1;
       1  0  0  0  0;
       0  1  0  1  0];
p.D = diag(sum(p.A, 2));    % Follower in-degree matrix.

% B describes which followers directly receive the leader signal.
p.B = diag([1, 0, 1, 0, 0]); 
p.Gamma = p.L + p.B;         % Augmented Laplacian used in leader-following errors.

%% 3. 领导者参考轨迹设置 (Leader reference signal) - 自动求导
% 【终极极简修改区】：从此以后，你只需要修改 yr_sym 这一行！速度和加速度交由 MATLAB 自动计算。

syms t_sym; % 声明系统符号变量 t_sym

% =========================================================================
% 👉 只需要修改这里：输入你的轨迹公式 (请务必使用 t_sym 作为时间变量)
yr_sym = 10.0 * sin(0.30 * t_sym); 
% =========================================================================

% MATLAB 自动进行符号求导 (妈妈再也不用担心我算错导数了)
dyr_sym = diff(yr_sym, t_sym);      % 自动计算一阶导数 (速度)
ddyr_sym = diff(dyr_sym, t_sym);    % 自动计算二阶导数 (加速度)

% 自动打包成供仿真底层高速调用的匿名函数
p.ref.yr = matlabFunction(yr_sym, 'Vars', t_sym);
p.ref.dyr = matlabFunction(dyr_sym, 'Vars', t_sym);
p.ref.ddyr = matlabFunction(ddyr_sym, 'Vars', t_sym);

% 自动提取公式文本，用于控制台打印显示
p.ref.expression = ['y_r(t) = ', char(yr_sym)];

%% 4. Predefined-time and controller parameters
% Practical settling-time estimate:
% T <= sqrt(2)*pi*(2*N*n)^(p/2)/(2*p*k1),
% where k1=min{k_{i,j},1/(p*Tc)}.
%% 4. Predefined-time and controller parameters
p.Ttarget = 10.0;           % [修改] 目标视觉收敛时间设为 10 秒
p.Tc_obs = 5.00;            % 保持观测器节奏
p.Tc_ctrl = 8.00;           % [修改] 将控制器预定义常数大幅放宽至 8.00
p.power = 0.15;   
p.k = [0.20, 1.0];           
% p.k = [0.70, 4.50];         % [修改] 降低控制增益，k1=1.20 柔化初始推力，k2=2.50 提供适度阻尼
p.kMat = repmat(p.k, p.N, 1); 
p.k1Bound = min([p.kMat(:); 1/(p.power * p.Tc_ctrl)]); 

p.practicalTimeBound = sqrt(2) * pi * (2*p.N*p.n)^(p.power/2) / ...
    (2*p.power*p.k1Bound);  
     



%% 5. Observer parameters
% The observer follows

% dot{Ohat}=lambda1/2^(1-2p)*sig^(1-2p)(Otilde)
%          +lambda2/2^(1+2p)*sig^(1+2p)(Otilde)
%          +lambda3/2*sig(Otilde)+k2*sig^0(Otilde).
% [修改] 将原有的 p.Tc 全部替换为 p.Tc_obs
p.lambda1 = 2^(-p.power) / (p.power * p.Tc_obs); 
p.lambda2 = 2^( p.power) / (p.power * p.Tc_obs); 
p.lambda3 = 2 / (p.power * p.Tc_obs);            
p.obsK2 = 1.0;

%% 6. Self-triggered mechanism parameters
% t_{k+1}^i=t_k^i+(iota_{i,1}|w_i(t_k^i)|+iota_{i,2})/
% max{Theta_i, |dot{w}_i(t_k^i)|}.
% Larger iota values increase the interval; larger Theta decreases the
% interval when Theta dominates |mu_i|.
% p.iota1 = [0.10; 0.05; 0.1; 0.2; 0.2]; 
% p.iota2 = [2.5; 2.6; 2.7; 2.8; 2.9];          
% p.Theta = [15.00; 16.00; 17.00; 18.00; 19.00];      
% p.minTriggerInterval = 0.01;                       
% p.maxTriggerInterval = 0.1;                     % Numerical upper bound to avoid stale held inputs.

% p.iota1 = [0.05; 0.10; 0.05; 0.15; 0.20];           % 拓扑权重：边缘节点对瞬态误差更包容
% p.iota2 = [2.00; 4.00; 2.00; 4.50; 5.00];           % 拓扑权重：中间和末端节点(2,4,5)容忍度翻倍
% p.Theta = [18.00; 12.00; 18.00; 10.00; 8.00];       % 拓扑权重：核心节点(1,3)保持敏锐，边缘节点迟钝化 
% p.minTriggerInterval = 0.01;                       
% p.maxTriggerInterval = 0.40;                        % [关键修改] 解除封印！允许边缘节点最长闭眼 0.4 秒

% p.iota1 = [0.08; 0.08; 0.08; 0.15; 0.15];           % 适度回调瞬态容忍，应对动态攻击
% p.iota2 = [2.20; 3.00; 2.20; 3.50; 3.80];           % 稳态容忍度取折中值
% p.Theta = [16.00; 14.00; 16.00; 13.00; 12.00];      % 配合分层，收窄上下游的差距
% p.minTriggerInterval = 0.01;                       
% p.maxTriggerInterval = 0.15;                        % 【核心平衡点】将最大滑行时间严格卡在 0.15 秒！

% p.iota1 = [0.08; 0.1; 0.08; 0.15; 0.15];           % 适度回调瞬态容忍，应对动态攻击
% p.iota2 = [2.20; 4.00; 2.20; 4.50; 5.00];           % 稳态容忍度取折中值
% p.Theta = [16.00; 14.00; 16.00; 13.00; 12.00];      % 配合分层，收窄上下游的差距
% p.minTriggerInterval = 0.01;                       
% p.maxTriggerInterval = 0.2;                        % 【核心平衡点】将最大滑行时间严格卡在 0.15 秒！

p.iota1 = [0.08; 0.1; 0.08; 0.15; 0.15];           % 适度回调瞬态容忍，应对动态攻击
p.iota2 = [0.20; 0.24; 0.20; 0.28; 0.30];           % 稳态容忍度取折中值
p.Theta = [0.80; 0.70; 0.80; 0.60; 0.50];      % 配合分层，收窄上下游的差距
p.minTriggerInterval = 0.01;                       
p.maxTriggerInterval = 0.30;                        % 【核心平衡点】将最大滑行时间严格卡在 0.15 秒！

%% 7. Deception attack coefficients
% Attacked measurement: xhat_{i,l}=beta_{i,l}(t)*x_{i,l}.
% beta_{i,l}(t)=betaBase_{i,l}+betaAmp_{i,l}*
% sin(betaFreq_{i,l}*t+betaPhase_{i,l}).
p.betaBase = [1.00 1.00;
              1.00 1.00;
              1.00 1.00;
              1.00 1.00;
              1.00 1.00];
% [修改] 放大攻击幅度至 14%~18%，以突出抗攻击控制器的视觉效果和鲁棒性
p.betaAmp = [0.018 0.016;
             0.016 0.014;
             0.014 0.016;
             0.016 0.014;
             0.016 0.016]; 
p.betaFreq = [0.45 0.55;
              0.50 0.42;
              0.38 0.47;
              0.44 0.52;
              0.41 0.49];   
p.betaPhase = [0.0 0.6;
               0.4 0.2;
               0.8 0.1;
               0.3 0.9;
               0.7 0.5];    
p.betaMin = 0.2;

%% 8. Plant uncertainty and external disturbance
p.f1Gain = 0.0;              % Unknown term gain in the first channel.
p.d1Gain = 0.0;              % Disturbance gain in the first channel.
p.f2Gain = 0.02;             % Position-dependent unknown term gain in the second channel.
p.f2PositionScale = 0.25;    % Scaling inside sin(x_{i,1}) for f_{i,2}.
p.f2VelocityGain = 0.02;     % Velocity-dependent unknown term gain in f_{i,2}.
p.d2Gain = 0.01;             % Disturbance gain in the second channel.
p.d2Freq = 0.5;              % Disturbance frequency in the second channel.
p.d2AgentPhaseStep = 0.25;   % Agent-dependent phase step in d_{i,2}.

%% 9. Active attack intervals for shaded regions
% These intervals are used only for visualizing attack-active time windows.
% P.ATTACKWINDOWS = [1.10 1.35;
%                    3.40 3.85;
%                    6.20 6.90;
%                    10.80 11.60;
%                    15.80 17.00;
%                    20.50 22.60];   % [新增] 20秒后的第一次攻击


p.attackWindows = [1.10 1.35;
                   3.40 3.85;
                   6.20 6.90;
                   10.80 11.60;
                   13.80 15.00];

%% 10. Initial conditions
% Each row is [initial position, initial velocity] of a follower agent.
p.x0 = [-5.00   0.5;
        -1.25  -0.2;
         2.50   0.3;
         6.25  -0.4;
        10.00   0.1];      % Follower initial states.
p.Ohat0 = zeros(p.N, p.n); % Initial observer estimates.
p.uHold0 = zeros(p.N, 1);  % Initial held actual inputs.
p.nextTrigger0 = zeros(p.N, 1); % Initial next trigger times.

%% 11. Numerical smooth functions
p.sigEps = 1e-8;            % [修改] 恢复极小的偏移量，确保零点附近的计算精度
p.sigSlope = 50.0;          % [修改] 重新提高陡度至 30.0，消除稳态跟踪误差，死死咬住目标轨迹

%% 12. Plot style parameters
p.plot.leaderLineWidth = 2.4;      % Leader trajectory line width.
p.plot.agentLineWidth = 1.5;       % Follower trajectory line width.
p.plot.triggerMarkerSize = 18;     % Scatter marker size for trigger instants.
p.plot.triggerLineWidth = 0.8;     % Marker edge width for trigger instants.
p.plot.zeroLineWidth = 1.0;        % Width of the zero reference line in error plot.
p.plot.attackColor = [0.62 0.59 0.53]; % Shaded attack interval color.
p.plot.attackAlpha = 0.48;         % Shaded attack interval transparency.
p.plot.attackEdgeWidth = 0.8;      % Shaded attack interval edge width.
p.plot.axisLineWidth = 1.2;        % Axes line width.
p.plot.fontName = 'Times New Roman'; % Font used in figures.
p.plot.fontSize = 11;              % Axis font size.
p.plot.gridAlpha = 0.18;           % Grid transparency.
p.plot.renderer = 'opengl';        % OpenGL usually gives smoother line rendering in MATLAB figures.
p.plot.graphicsSmoothing = 'on';   % Enable figure graphics smoothing when the MATLAB version supports it.
p.plot.exportResolution = 600;     % Suggested resolution for exported paper figures.

end
